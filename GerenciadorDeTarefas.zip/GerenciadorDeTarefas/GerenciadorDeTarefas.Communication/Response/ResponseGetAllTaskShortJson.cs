﻿namespace GerenciadorDeTarefas.Communication.Response;

public class ResponseGetAllTaskShortJson
{
    public List<ResponseGetAllTaskDetailsJson> Tasks { get; set; } = []; 
}
