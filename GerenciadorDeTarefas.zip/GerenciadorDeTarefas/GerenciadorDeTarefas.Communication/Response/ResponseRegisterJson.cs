﻿namespace GerenciadorDeTarefas.Communication.Response;

public class ResponseRegisterJson
{
    public int Id { get; set; }
    public string Name { get; set; }
}
