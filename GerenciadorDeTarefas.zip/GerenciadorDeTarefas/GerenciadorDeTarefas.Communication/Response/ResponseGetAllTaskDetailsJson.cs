﻿using GerenciadorDeTarefas.Communication.Enums;

namespace GerenciadorDeTarefas.Communication.Response;

public class ResponseGetAllTaskDetailsJson
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Descryption { get; set; } = string.Empty;
    public Priority TaskPriority { get; set; }
    public DateTime DateLimiteTask { get; set; }
    public Status Status { get; set; }
}
