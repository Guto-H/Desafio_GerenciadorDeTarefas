﻿namespace GerenciadorDeTarefas.Communication.Response;

public class ResponseErrorsJson
{
    public List<string> Errors { get; set; } = [];
}
