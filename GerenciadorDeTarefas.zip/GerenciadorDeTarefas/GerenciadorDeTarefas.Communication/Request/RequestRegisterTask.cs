﻿using GerenciadorDeTarefas.Communication.Enums;

namespace GerenciadorDeTarefas.Communication.Request;

public class RequestRegisterTask
{
    public string Name { get; set; } = string.Empty;
    public string Descryption { get; set; } = string.Empty ;
    public Priority TaskPriority { get; set; }
    public DateTime DateLimiteTask { get; set; }

}
