﻿namespace GerenciadorDeTarefas.Communication.Enums;

public enum Priority
{
    alta = 1,
    media = 2,
    baixa = 3,
}
