﻿namespace GerenciadorDeTarefas.Communication.Enums;

public enum Status
{
    concluida = 1,
    em_andamento = 2,
    aguardando = 3,
}
