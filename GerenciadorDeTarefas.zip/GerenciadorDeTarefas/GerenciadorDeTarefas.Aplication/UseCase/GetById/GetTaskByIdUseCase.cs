﻿using GerenciadorDeTarefas.Communication.Response;

namespace GerenciadorDeTarefas.Aplication.UseCase.GetById;

public class GetTaskByIdUseCase
{
    public ResponseGetTaskByIdJson Execute(int id)
    {
        return new ResponseGetTaskByIdJson
        {
            Id = id,
            Name = "Tarefa EndPoints",
            Descryption = "Criar 4 End Points diferentes com respectivos responses para cada",
            DateLimiteTask = new DateTime(year: 2024, month: 9, day: 17),
            TaskPriority = Communication.Enums.Priority.media,
            Status = Communication.Enums.Status.concluida,
        };
    }
}
