﻿namespace GerenciadorDeTarefas.Aplication.UseCase.DeleteById;

public class DeleteTaskByIdUseCase
{
    public void Execute(int id)
    {

    }
}
