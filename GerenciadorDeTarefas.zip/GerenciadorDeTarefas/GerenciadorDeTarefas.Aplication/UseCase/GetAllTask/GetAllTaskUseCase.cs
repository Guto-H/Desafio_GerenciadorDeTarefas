﻿using GerenciadorDeTarefas.Communication.Response;

namespace GerenciadorDeTarefas.Aplication.UseCase.GetAllTask;

public class GetAllTaskUseCase
{
    public ResponseGetAllTaskShortJson Execute()
    {
        return new ResponseGetAllTaskShortJson
        {
            Tasks = new List<ResponseGetAllTaskDetailsJson>
            {
                new ResponseGetAllTaskDetailsJson
                {
                    Id = 10,
                    Name = "Desafio de API",
                    Descryption = "Desenvolver um gerenciador de tarefas",
                    TaskPriority = Communication.Enums.Priority.alta,
                    DateLimiteTask = new DateTime(year: 2024, month: 9, day: 18),
                    Status = Communication.Enums.Status.concluida,
                }
            }
        
        };
    }
}
