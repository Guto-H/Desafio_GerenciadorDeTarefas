﻿using GerenciadorDeTarefas.Communication.Request;

namespace GerenciadorDeTarefas.Aplication.UseCase.Update;

public class UpdateTaskByIdUseCase
{
    public void Execute(int id, RequestRegisterTask request)
    {
        
    }
}
