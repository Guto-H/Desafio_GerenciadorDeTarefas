﻿using GerenciadorDeTarefas.Communication.Request;
using GerenciadorDeTarefas.Communication.Response;

namespace GerenciadorDeTarefas.Aplication.UseCase.Register;

public class RegisterTaskUseCase
{
    public ResponseRegisterJson Execute(RequestRegisterTask request)
    {
        return new ResponseRegisterJson
        {
            Id = 10,
            Name = request.Name,
        };
    }
}
