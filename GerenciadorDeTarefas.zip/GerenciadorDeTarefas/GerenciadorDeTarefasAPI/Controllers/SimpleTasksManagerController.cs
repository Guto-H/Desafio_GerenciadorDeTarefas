﻿using GerenciadorDeTarefas.Aplication.UseCase.DeleteById;
using GerenciadorDeTarefas.Aplication.UseCase.GetAllTask;
using GerenciadorDeTarefas.Aplication.UseCase.GetById;
using GerenciadorDeTarefas.Aplication.UseCase.Register;
using GerenciadorDeTarefas.Aplication.UseCase.Update;
using GerenciadorDeTarefas.Communication.Request;
using GerenciadorDeTarefas.Communication.Response;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GerenciadorDeTarefasAPI.Controllers;
[Route("api/[controller]")]
[ApiController]
public class SimpleTasksManagerController : ControllerBase
{
    [HttpPost]
    [ProducesResponseType(typeof(ResponseRegisterJson), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ResponseErrorsJson), StatusCodes.Status400BadRequest)]
    public IActionResult Register([FromBody] RequestRegisterTask request)
    {
        var RegisterUseCase = new RegisterTaskUseCase().Execute(request);

        return Created(string.Empty, RegisterUseCase);
    }


    [HttpGet]
    [ProducesResponseType(typeof(ResponseGetAllTaskShortJson), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public IActionResult GetAllTasks() {

        var GetAllTask = new GetAllTaskUseCase().Execute();

        if (GetAllTask.Tasks.Any())
        {
            return Ok(GetAllTask);
        }

        return NoContent();
    }


    [HttpGet]
    [Route("{id}")]
    [ProducesResponseType(typeof(ResponseGetTaskByIdJson), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ResponseErrorsJson), StatusCodes.Status404NotFound)]
    public IActionResult GetTaskById(int id)
    {
        var GetByIdUseCase = new GetTaskByIdUseCase().Execute(id);

        return Ok(GetByIdUseCase);
    }


    [HttpPut]
    [Route("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ResponseErrorsJson), StatusCodes.Status400BadRequest)]
    public IActionResult UpdateTask([FromRoute]int id, [FromBody] RequestRegisterTask request)
    {

        var UpdateTaskById = new UpdateTaskByIdUseCase();

        UpdateTaskById.Execute(id, request);

        return NoContent();
    }


    [HttpDelete]
    [Route("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ResponseErrorsJson), StatusCodes.Status404NotFound)]

    public IActionResult DeleteTaskById(int id)
    {
        var DeleteByIdUseCase = new DeleteTaskByIdUseCase();
        DeleteByIdUseCase.Execute(id);

        return NoContent();
    }
}
